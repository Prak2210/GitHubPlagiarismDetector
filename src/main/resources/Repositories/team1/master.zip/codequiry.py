class Codequiry(object):
    def __init__(self,
                 api_key):
        if not api_key:
            raise ValueError("API Key is required and cannot be null")

        self.api_key = api_key

        parser = ConfigParser()
        parser.read('config.ini')
        self.API_BASE_URL = parser.get('config', 'api_base_url')
        self.API_UPLOAD_URL = parser.get('config', 'api_upload_url')
        self.SOCKETS_BASE_URL = parser.get('config', 'sockets_base_url')
        self.SDK_VERSION = parser.get('config', 'sdk_version')

        self.base_headers = {
            'apikey': api_key,
            'Content-Type': 'application/json'
        }

        session = requests.Session()
        # session.mount(self.API_BASE_URL, SSLAdapter())
        session.headers = self.base_headers
        self.session = session

package dto;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class Results {
    Map<Pair, Double> rows;

    public Results(Map<Pair,Double> rows) {
        this.rows = rows;
    }

    /**
     * Displays the Codequiry plagiarism results
     */
    public void displayResults() {

        int ind=0, size=0;
        for (Map.Entry<Pair, Double> row : rows.entrySet()) {
            //List<String> x = new ArrayList<String>();
            size++;
            Pair pair = row.getKey();
            int referenceID = pair.getReference().getRepoIndex();
            int referredID = pair.getReferred().getRepoIndex();
            String referenceTeam = pair.getReference().getTeam();
            String referredTeam = pair.getReferred().getTeam();
            double plagiarism = row.getValue();

            System.out.println("Source Team ID:" + referenceID + " Authors: " + referenceTeam +
                    " Compared with Team ID: " + referredID + " and Authors: " + referredTeam + " " + plagiarism);


        }

        String [][] data = new String[size][5];
        for (Map.Entry<Pair, Double> row : rows.entrySet()) {

            Pair pair = row.getKey();
            int referenceID = pair.getReference().getRepoIndex();
            int referredID = pair.getReferred().getRepoIndex();
            String referenceTeam = pair.getReference().getTeam();
            String referredTeam = pair.getReferred().getTeam();
            double plagiarism = row.getValue();
            data[ind][0] = Integer.toString(referenceID);
            data[ind][1] = referenceTeam;
            data[ind][2] = Integer.toString(referredID);
            data[ind][3] = referredTeam;
            data[ind][4] = Double.toString(plagiarism);
            ind++;

        }
        JFrame frame; JTable table;
        frame =  new JFrame();

        frame.setTitle("Plagiarism Results");

        String[] columnNames = {"Source Team ID", "Authors", "Comapred with Team ID", "Authors", "Plagiarism"};
        table = new JTable(data, columnNames);
        table.setBounds(30, 40, 200, 300);

        JScrollPane sp = new JScrollPane(table);
        frame.add(sp);
        frame.setSize(500, 200);
        frame.setVisible(true);
    }
}

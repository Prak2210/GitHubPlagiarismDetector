package dto;

import java.util.Arrays;
import java.util.List;

public class Repository {
    private int repoIndex;
    private String repoLink; //link to their github repository
    private String localLink; // local url to access their repository on our machine
    private List<String> team; //unityids
    private static int index = 1;


    //change the below path to your local machine (up to "/git")
    private final static String LOCALPATH = "/Users/prakshat/Documents/git/GitHubPlagiarismDetector/src/main/resources/Repositories/team";


    public Repository(String[] teamData) {
        this.repoIndex = index++;
        this.team = Arrays.asList(teamData[1].split(","));
        this.repoLink = teamData[2];

        this.localLink = LOCALPATH + this.repoIndex + "/";
    }

    /**
     *
     * @return True if there are more than 1 member in the team. Otherwise False.
     */
    public boolean isTeamProject() {
        if (team.size() > 1) {
            return true;
        }
        return false;
    }

    /**
     *
     * @return Repository Information
     */
    public String show() {
        return "ID: " + repoIndex + " Team: " + team.toString() + " URL: " + repoLink + " Local-Path: " + localLink;
    }

    /**
     *
     * @return Unity IDs of team members
     */
    public String getTeam() {
        return team.toString();
    }

    /**
     *
     * @return Repository Index
     */
    public int getRepoIndex() {
        return this.repoIndex;
    }

    /**
     *
     * @return Local path to cloned repository
     */
    public String getLocalLink() {
        return this.localLink;
    }

    /**
     *
     * @return URL to Github Repository
     */
    public String getRepoLink() {
        return this.repoLink;
    }


}
